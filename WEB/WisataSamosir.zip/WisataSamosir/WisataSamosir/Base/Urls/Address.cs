﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WisataSamosir.Base.Urls
{
    public class Address
    {
        public string link = "https://localhost:44365/API/";
    }
}
