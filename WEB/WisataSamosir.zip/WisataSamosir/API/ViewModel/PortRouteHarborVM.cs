﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.ViewModel
{
    public class PortRouteHarborVM
    {
        public string Harbor{ get; set; }
    }
}
