﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.ViewModel
{
    public class PortRouteVM
    {
        public string Description { get; set; }
        public int Harbor_start { get; set; }
        public int Harbor_end { get; set; }
    }
}
