﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.ViewModel
{
    public class HarborVM
    {

        public string HarborName { get; set; }
        public double Latitude{ get; set; }
        public double Longitude { get; set; }

    }
}
