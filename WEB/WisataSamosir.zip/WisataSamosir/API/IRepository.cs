﻿namespace API
{
    internal interface IRepository
    {
    }
}